lms-php-app
This repository is for my PHP MySQL Library Management System that i have done for a project in college for Web services & Applications


In order to use this project you need to instal LAMP/WAMP and create folder library in htdocs folder so that you can use localhost to test this application. Then you need to add this files to library folder and also you need to create database called library and add sql file in phpmyadmin dashboard..

And also you can check out my project live that i have hosted :

https://aleksandartrifunovic1.000webhostapp.com/

If you want to check out admin panel you need to have following credentials :

username : admin
password : admin!!123

Of course this credentials only work for admin registrations


