   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                Online Library Management System |<a href="https://www.linkedin.com/" target="_blank"  > Designed by : M.Sc 11 batch</a> 
                </div>

            </div>
        </div>
    </section>
